

Esse projeto foi desenvolvido com o intuito de avaliação de capacidade técnica, seguindo o que foi solicitado, como principal objetivo de armazenamento e apresentação dos novos membros, utilizando inicialmente um fluxograma para organização e detalhar cada etapa do projeto, e seguindo o arquivo index.php para dar continuidade e funcionamento do projeto.
